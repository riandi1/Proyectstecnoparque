<?php

namespace App\Models\System;

use App\Models\Model;

class Permission extends Model
{

}
