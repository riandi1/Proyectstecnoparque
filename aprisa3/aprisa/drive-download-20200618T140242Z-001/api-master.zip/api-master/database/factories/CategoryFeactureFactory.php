<?php

use Faker\Generator as Faker;

$factory->define(App\CategoryFeacture::class, function (Faker $faker) {
    return [
        //
    ];
});
