@extends('mails.base')

@section('mail-content')
    {!! $html_content !!}
@endsection
