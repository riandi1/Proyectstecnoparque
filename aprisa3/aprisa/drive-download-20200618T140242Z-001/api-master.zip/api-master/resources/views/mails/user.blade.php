<div>
    {!! $html_content !!}
</div>
