export class Marcador {
  constructor(public lat: number, public lng: number) { }
}