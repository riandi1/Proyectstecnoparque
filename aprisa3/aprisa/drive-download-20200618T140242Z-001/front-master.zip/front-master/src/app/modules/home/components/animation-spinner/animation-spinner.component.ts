import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animation-spinner',
  templateUrl: './animation-spinner.component.html',
  styleUrls: ['./animation-spinner.component.scss']
})
export class AnimationSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
